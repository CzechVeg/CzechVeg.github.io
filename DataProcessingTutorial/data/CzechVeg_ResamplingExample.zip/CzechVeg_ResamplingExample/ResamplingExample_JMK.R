#This project shows how to resample a set of vegetation plots from South Moravia 
#(a subset of the CzechVeg-Open dataset) using the Resampler R package.

#Link to the tutorial for resampling with the CzechVeg-Open dataset
#https://czechveg.github.io/DataProcessingTutorial/data_resampling.html

#Install and load required packages
pkgs <- c("data.table", "cli", "spdep", "igraph", "Matrix", "vegan", "tidyverse",
          "sf", "terra", "dbscan", "remotes")
lapply(pkgs, function(pkg) {
  if (!requireNamespace(pkg, quietly = TRUE)) install.packages(pkg)
  library(pkg, character.only = TRUE)
})

#define function for plotting results
compare_data <- function(x, y, eps = 10000, pt.size = 0.6) {
  bind_rows(
    mutate(as.data.frame(x[, c("Lon", "Lat")]), 
           no_plots = lengths(frNN(as.matrix(x[, c("Lon", "Lat")]), eps = eps)$dist), 
           Type = paste0("Before (N = ", nrow(x), ")")),
    mutate(as.data.frame(y[, c("Lon", "Lat")]), 
           no_plots = lengths(frNN(as.matrix(y[, c("Lon", "Lat")]), eps = eps)$dist), 
           Type = paste0("After (N = ", nrow(y), ")"))) %>% 
    mutate(Type = factor(Type, levels = c(paste0("Before (N = ", nrow(x), ")"), 
                                          paste0("After (N = ", nrow(y), ")")))) %>%
    ggplot(aes(x = Lon, y = Lat, color = no_plots)) +
    geom_point(size=pt.size) +
    scale_color_viridis_c() +
    facet_wrap( ~ Type) +
    theme_bw()
}


##Load vegetation-plot data-----------------------------------------------------
#load header data
header_data <- read.csv("PlotCoordinates_SouthMoravia.csv", header = TRUE)

#load species data in long format
species_data <- read.csv("SpeciesData_SouthMoravia.csv", header = TRUE)

#check header data
head(header_data); nrow(header_data)
summary(header_data)

#check species data
head(species_data); length(unique(species_data$species))

#Transform geographical coordinates from degrees to meters 
#(projected coordinate system WGS 84 / UTM zone 33N)
header_data[, c("Lon", "Lat")] <- terra::project(as.matrix(header_data[, c("Lon", "Lat")]), 
                                                 from = "epsg:4326", 
                                                 to = "epsg:32633")

#check transformed coordinates
head(header_data)

#plot vegetation plots with their density
header_data %>% select(Lon:Lat) %>% 
  mutate(no_plots = lengths(frNN(base::as.matrix(.), eps = 10000)$dist))  %>%  
  ggplot(aes(x = Lon, y = Lat, color = no_plots)) +
  geom_point(size=0.8) +
  scale_color_viridis_c() +
  theme_bw()

#Assign required column names
colnames(header_data)[1] <- "PlotObservationID"
colnames(species_data) <- c("PlotObservationID", "Taxon_name", "cover")

head(header_data)
head(species_data)

##Run resampling without stratification (the simplest case)---------------------
#https://github.com/jdivisek/Resampler

#Install Resampler package
if (!requireNamespace("Resampler", quietly = TRUE)) {
  remotes::install_github("jdivisek/Resampler")
}
library(Resampler)

##RUN 1 ***********
#Distance 500 m & Simpson similarity 0.5 & random plot removal
res1 <- resample_plots(coord = data.table(header_data),
                       spec = data.table(species_data), 
                       longlat = FALSE, 
                       dist.threshold = 500, 
                       sim.threshold = 0.5,
                       inclusive = FALSE,
                       sim.method = "simpson",
                       remove = "random",
                       decision.variable = NULL, 
                       strata = NULL, 
                       seed = 1234)

#compare results
compare_data(header_data, res1, eps = 10000, pt.size = 0.6)

##RUN 2 ***********
#Remove ALL plots within specified neighborhood
res2 <- resample_plots(coord = data.table(header_data),
                       spec = data.table(species_data), 
                       longlat = FALSE, 
                       dist.threshold = 500, 
                       sim.threshold = 0,
                       inclusive = TRUE,
                       sim.method = "simpson",
                       remove = "random",
                       decision.variable = NULL, 
                       strata = NULL, 
                       seed = 1234)

#check minimum distance between plots
res2 %>% select(Lon:Lat) %>% dist() %>% min()

#compare results
compare_data(header_data, res2, eps = 10000, pt.size = 0.6)

##RUN 3 ***********
#Remove ONLY compositionally identical plots within specified neighborhood
res3 <- resample_plots(coord = data.table(header_data),
                       spec = data.table(species_data), 
                       longlat = FALSE, 
                       dist.threshold = 500, 
                       sim.threshold = 1,
                       inclusive = TRUE,
                       sim.method = "simpson",
                       remove = "random",
                       decision.variable = NULL, 
                       strata = NULL, 
                       seed = 1234)

#compare results
compare_data(header_data, res3, eps = 10000, pt.size = 0.6)

##RUN 4 ***********
#Remove OLDER plots within specified neighborhood
res4 <- resample_plots(coord = data.table(header_data),
                       spec = data.table(species_data), 
                       longlat = FALSE, 
                       dist.threshold = 500, 
                       sim.threshold = 0.5,
                       inclusive = FALSE,
                       sim.method = "simpson",
                       remove = "lower value",
                       decision.variable = "YEAR", 
                       strata = NULL, 
                       seed = 1234)

#compare results
compare_data(header_data, res4, eps = 10000, pt.size = 0.6)

##Load environmental stratification----------------------------------------------
strata <- read_sf("./GIS_data/cz_grid1km_utm_JMK.shp")
head(strata)
length(unique(strata$Env_strata))

plot(strata["Env_strata"], border=F) #plot env. strata

#plot both strata and plots
# ggplot() +
#   geom_sf(data = strata, aes(fill = Env_strata), colour = NA) +
#   geom_sf(data = st_as_sf(coord, coords = c("Lon", "Lat"), crs = 32633), shape = 4) +
#   theme_bw() +
#   theme(legend.position="none")

#assign env_strata to vegetation plots
header_data %>% 
  st_as_sf(coords = c("Lon", "Lat"), crs = 32633) %>% 
  st_join(x = ., y = strata, left = T) %>% 
  st_drop_geometry() %>% 
  select(all_of(c("PlotObservationID", "Env_strata"))) %>% 
  left_join(x = header_data, y = ., by="PlotObservationID") -> header_data

head(header_data)
summary(header_data$Env_strata)

##Run resampling with stratification -------------------------------------------

##RUN 5 ***********
#Distance 500 m & Simpson similarity 0.5 & random plot removal
res5 <- resample_plots(coord = data.table(header_data),
                       spec = data.table(species_data), 
                       longlat = FALSE, 
                       dist.threshold = 500, 
                       sim.threshold = 0.5,
                       inclusive = FALSE,
                       sim.method = "simpson",
                       remove = "random",
                       decision.variable = NULL, 
                       strata = "Env_strata", 
                       seed = 1234)

nrow(res1); nrow(res5)

#compare results
compare_data(header_data, res5, eps = 10000, pt.size = 0.6)

# #Export data to shapefile
# header_data %>%
#   st_as_sf(coords = c("Lon", "Lat"), crs = 32633) %>%
#   st_write(., paste0(getwd(), "/GIS_data/", "JMK_Before_resampling.shp"))
# 
# res1 %>% as.data.frame() %>%
#   st_as_sf(coords = c("Lon", "Lat"), crs = 32633) %>%
#   st_write(., paste0(getwd(), "/GIS_data/", "JMK_After_resampling.shp"))

