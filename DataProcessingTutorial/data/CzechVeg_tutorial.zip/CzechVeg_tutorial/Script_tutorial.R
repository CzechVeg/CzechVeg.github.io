library(foreign)   #for reading dbf files
library(tidyverse) #for data handling, pipes and visualisation
library(readxl)    #for data import directly from Excel
library(janitor)   #for unified, easy-to-handle format of variable names



# TIPS ------------------------------------------------------------------
# list all the libraries your code needs at the beginning of the script
# add notes to your scripts, you will be grateful later
# change the text to non-active (marked with hash tags #) Ctrl + Shift + C
# use separate scripts or sections
# insert named section using Ctrl + Shift + R or divide the code by four #
# fold all sections with Alt + O
# unfold all with Shift + Alt + O
# variable names should be short and easy to handle, without spaces, strange symbols
# simple variable names will save you a great deal of time and parentheses

# see more here:
#   https://botzooldataanalysis.github.io/DataManipulationVisualisation/1_introduction.html


